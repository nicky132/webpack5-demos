const mergewWebpack = require('webpack-merge');
const common = require('./webpack.common');
const path = require('path');
module.exports = mergewWebpack.merge(common, {
    // 动态监测并实时更新页面
    devServer: {
        static: { // static: ['assets']
            directory: path.join(__dirname, 'src')
        },
    },
});