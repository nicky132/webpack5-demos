const path = require('path');
module.exports = {
    // 入口js路径
    entry: './src/index.js',
    // 编译输出的js及路径
    output: {
        filename: 'bundle.js',
        path: path.resolve(__dirname, 'dist')
    }
};