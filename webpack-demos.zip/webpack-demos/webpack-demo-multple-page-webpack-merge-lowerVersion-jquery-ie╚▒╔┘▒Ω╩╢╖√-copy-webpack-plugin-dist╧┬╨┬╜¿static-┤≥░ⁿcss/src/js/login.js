import '../css/common/frame.css';
import '../css/pages/login.styl';
$('#info').text('jQuery正常使用login');