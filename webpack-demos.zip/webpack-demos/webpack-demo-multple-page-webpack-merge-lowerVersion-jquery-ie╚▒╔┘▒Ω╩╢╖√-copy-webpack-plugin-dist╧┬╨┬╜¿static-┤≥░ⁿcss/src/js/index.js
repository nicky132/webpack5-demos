import '../css/common/frame.css';
import '../css/pages/index.styl';
$('#info').text('jQuery正常使用index');